
<?php
use Aws\S3\S3Client;
use Aws\Sqs\SqsClient;
use Aws\Ecs\EcsClient;
use Aws\Exception\AwsException;
 
require_once '/vendor/autoload.php';
include('_function.php');
 
$filename = '';
$listData=[];
$key = 'AKIAZC6U4MOHHXX3YROM';
$secret = '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';
 
try {
    // SQS CLient
    $sqsClient = new SqsClient([
        'region' => 'us-east-1',
        'version' => '2012-11-05',
        'credentials' => array(
            'key'    => $key,
            'secret' => $secret,
        )
    ]);
 
    // S3 client
    $s3client = new S3Client([
        'version'     => 'latest',
        'region'      => 'us-east-1', //Region of the bucket
        'credentials' => array(
            'key'    => $key,
            'secret' => $secret,
        )
    ]);
 
    $bucket_name = "support-doc-pdfs";
 
    try {
        $queueUrl = 'https://sqs.us-east-1.amazonaws.com/624827327374/pdfpng';
        $result = $sqsClient->receiveMessage(array(
            'QueueUrl' => $queueUrl, // REQUIRED
            'MaxNumberOfMessages' => 1,
        ));
    
        if(isset($result['Messages'][0]['Body'])) {
            $bodyDetails = json_decode($result['Messages'][0]['Body']);
           
            //echo json_encode($bodyDetails);die;
            echo $fileName = $bodyDetails->detail->object->key;
           
            //remove message from queue
            $sqsClient->deleteMessage([
                'QueueUrl' => $queueUrl, // REQUIRED
                'ReceiptHandle' => $result['Messages'][0]['ReceiptHandle'] // REQUIRED
            ]);
 
            // tagging info
            $tagInfo = getTaggingInfo($fileName, $s3client, $bucket_name);
            // //
            
            if($fileName != ''){
                $listData[]=$fileName;
 
                $fileNameArray = explode('.', $fileName);
                $file_nameOnly = $fileNameArray[0];
                $file_extensionOnly = $fileNameArray[1];
 
                if($file_extensionOnly == 'pdf' || $file_extensionOnly == 'PDF') {
 
                    $cmd = $s3client->getCommand('GetObject', [
                        'Bucket' => $bucket_name,
                        'Key' => $fileName,
                        'ResponseContentDisposition' => 'attachment; filename="'.$fileName.'"',
                    ]);
 
                    $request = $s3client->createPresignedRequest($cmd,'+5 minutes');
                    $file_secure_url_download = (string)$request->getUri();
 
                    // download pdf
                    $dir='./';
                    downloadPdf($fileName, $file_secure_url_download, $dir);

                    // remove existing png files
                    removePngFiles($dir, $fileName);
                    
                    // convert into png files
                    $tempDir = $fileName."~%02d.png";
                    exec("gs -d -dNOPAUSE -dDumpMediaSizes -sDEVICE=png16m -r300 -dDownScaleFactor=3 -dTextAlphaBits=4 -dGraphicsAlphaBits=4 -sOutputFile=$tempDir '$fileName' -dBATCH");
 
                    // pushing png file to another s3 bucket
                    $target_bucket_name = 'support-docs-pngs';
                   
                    $listOfImages = getListOfPngFiles($dir, $fileName);
                    //$listOfImages [] = 'download.png';
 
                    for($i=0;$i<sizeof($listOfImages);$i++){
                        $path = $listOfImages[$i];
                        echo $path;
                        // getting the image name and path
                        $imageFilename = pathinfo($path, PATHINFO_FILENAME);
                        $imageExtension = pathinfo($path, PATHINFO_EXTENSION);
                        $imageBaseName = pathinfo($path, PATHINFO_BASENAME);
 
                        // put object to the aws s3
                        putImagetoS3($fileName, $imageFilename, $imageExtension, $path, $target_bucket_name, $s3client, $tagInfo);                                          
                    }                   
                }else{ echo "We are processing pdf document, please check once agian.";}
            }
        } else {
            echo "SQS Messages Body is empty!.";
        }
 
    } catch(AwsException $e) {
        // output error message if fails
        error_log($e->getMessage());
    }
    
} catch (Exception $exception) {
    echo $exception->getMessage();
}
 
exit;
 
?>