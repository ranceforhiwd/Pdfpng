<?php
 
 
function downloadPdf($fileName, $file_secure_url_download, $dir='./') {
    try {
        //Initialize the cURL session
        $ch = curl_init($file_secure_url_download);
        $save_file_loc = $dir . $fileName;
        if(file_exists($save_file_loc)) {
            unlink($save_file_loc);
        }
        $fp = fopen($save_file_loc, 'wb');
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_exec($ch);
        curl_close($ch);
        fclose($fp);
    }
    catch(Exception $e) {
        echo 'Message: ' .$e->getMessage();
    }
}
function removePngFiles($dir, $fileName) {
    $pngFiles = glob($dir."*".$fileName."~*" );
    for($i =0; $i < sizeof($pngFiles); $i++){
        unlink($pngFiles[$i]);
    }
}
function getListOfPngFiles($dir, $fileName) {
    $pngFiles = glob($dir."*".$fileName."~*" );
    natsort($pngFiles);
    return $pngFiles;
}
function putImagetoS3($fileName, $name, $ext, $sourceFile, $target_bucket_name, $s3client, $tagInfo) {
 
    if($ext == 'png' || $ext == 'PNG') {
        try {
            // Upload
            $result = $s3client->putObject([
                'Bucket' => $target_bucket_name,
                'Key'    => $fileName.'_folder/'.$name.'.'.$ext,
                'SourceFile' => $sourceFile,
                'Tagging' => $tagInfo
            ]);
        } catch (S3Exception $e) {
            echo $e->getMessage();
            exit();
        }
    }
}
function createLogwithPngDetails($pdfName, $logStreamName ,  $cloudWatchClient){
        $logGroupName = '/aws/events/savepng';
 
        // $cloudWatchClient->createLogGroup(array(
        //     'logGroupName' => $logGroupName,
        // ));
 
        $a = explode("~",$logStreamName);      
        $pageNo = str_replace(".png","",$a[sizeof($a)-1]);
        
        $result = $cloudWatchClient->createLogStream([
            'logGroupName' => $logGroupName, // REQUIRED
            'logStreamName' => $logStreamName, // REQUIRED
        ]);
        
 
        $result = $cloudWatchClient->describeLogStreams([
            'logGroupName' => $logGroupName,
            'logStreamNamePrefix' => $logStreamName,
        ]);        
        $logStreams=$result->get('logStreams');
        if (!$logStreams)
            throw new \Exception('No log stream found');
        if (count($logStreams)!=1)
            throw new \Exception('Multiple log stream found');
      
        $result =$cloudWatchClient->putLogEvents([
            'logGroupName' => $logGroupName,
            'logStreamName' => $logStreamName,
            'logEvents' => [
                [    'timestamp' => round(microtime(true) * 1000),
                    // message is required
                    'message' => json_encode(['page'=> $pageNo, 'pdfname'=> $pdfName, 'imagename' => $logStreamName, 'imagefullpath' => $pdfName.'_folder/'.$logStreamName]),
                    
                ],
            ]
        ]);
    
 
}
function getTaggingInfo($fileName, $s3client, $bucket_name){
    $paths = $s3client->getObjectTagging([
        'Bucket' => $bucket_name,
        'Key' => $fileName,
    ]);
   
    $optionString ='';
        foreach($paths as $key => $path) {

           
            if($key == 'TagSet') {
                $i=1;
                foreach($path as $key => $options){
                    $optionString .= $options['Key'].'='.$options['Value'].'&';
                    $i++;
                }
            }
        }
   return rtrim($optionString, "&");
}
 
?>